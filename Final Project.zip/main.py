# Press the green button in the gutter to run the script.
import MainWindow as mw
import breezypythongui

if __name__ == '__main__':
    mw.MainWindow().mainloop()




